How to import the settings for the XTH-0-UNV transmitter.
1.	Connect 24V to pins 1 and 2 positive to pin 1.
2.	Connect XT-USB between computer and transmitter.
3.	Download XT-Soft program and launch.	
4.	Select proper port and type then select ok
5.	Import included settings (Temp_Set) for data consistency 
6.	Transmit set-up to unit
